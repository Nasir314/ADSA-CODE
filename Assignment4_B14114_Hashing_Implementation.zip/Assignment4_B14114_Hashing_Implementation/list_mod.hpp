#ifndef _list_H_
#define _list_H_
#include <cassert>

namespace ansari{
   
     template <typename T>
     class list {
 
                private:
                     class Node {
                             friend class list<T>;   // friend class 

                             private:
                             T data;
                             T key;
                            // int probe;
                             Node* next;

                             public:
                             Node(T k,T d, Node* n = NULL) : key(k),data(d), next(n) {}
                             };

                     Node* head; 
                     Node* tail; 
                     int count;
                     int c;  

               public:
                     list(const list<T>& x);  
                     ~list(void); 
                     list(void) : head(NULL), tail(NULL), count(0),c(0) {}
                     inline int length(void) {
                                     return count;
                     }
                     inline bool empty(void) {
                                     return count == 0;
                     }
                     void cons(const T& key,const T& value);
                     void remove(int x);
                     void append(const T& key,const T& value );
                     void append(list<T>& x);
                     void dump(void);
                      T& front(void) {
                           assert (head != NULL);
                           return head->data;
                     }
                   T& next(void){           // return the data (key and value)) corresponding the node and delete that
                            assert(head != NULL);
                            Node* temp;
                            temp=head;
                            head=head->next;
                            count--;
                            return temp->data;
                               }
                  T& next1(void){          //  return the key corresponding node 
                            assert(head != NULL);
                            Node* temp;
                            temp=head;
                            int t=0;
                         while(c!=t){
                            temp=temp->next;
                            t++;
                         }
                          c++;
                            //count--;
                            if(temp)
                               return temp->key;
                           //  else 
                             //  return ;
                               }
                 T& next2(void){        // return the key and value corresponding node 
                            assert(head != NULL);
                            Node* temp;
                            temp=head;
                            int t=0;
                         while(c!=t){
                            temp=temp->next;
                            t++;
                         }
                          c++;
                            //count--;
                            if(temp)
                               return temp->data;
                            // else 
                              // return "Not Found";
                               }
                 
                 
      };

/*
 * Adds a value to the front of the list.
 */
      template<typename T>
      void list<T>:: cons(const T& key,const T& value){  


                  Node* new_head = new Node(key,value,head);

                    if(this->empty()){
                            head = new_head;
                            tail = new_head;
                     }
                   else {
                            head = new_head;
                   }
                  count++;

       }

/*
 * Removes the first occurence of the value from list.
 */
       template<typename T>
       void list<T>:: remove(int x){

                 assert(head != NULL); 
                 Node  *current = head;

	         for (int  i=1;  i < x-1;  i++){
			current = current -> next;
	         }
	         Node  *p = head;
                 if(x==1){
                      head=head->next;
                 }
                else{        
	              p = current -> next;
	              current -> next = p -> next;
                }
	        delete  p;
                count--;
       }

/*
 * adds value at the end of the list.
 */
       template<typename T>
       void list<T>::append(const T& key,const T& value){ 

                Node* new_tail = new Node(key,value, NULL);

                if(this->empty()) {
                          head = new_tail;
                } 
               else {
                         tail->next = new_tail;
               }

               tail = new_tail;
               count++;
       }

/*
 * Appends the given list x at the end of the current list.
 */
       template<typename T>
       void list<T>::append(list<T>& x){

               Node *temp ;

               if ( head == NULL )
                      head = x.head ;
               else{
                     if ( x.head != NULL ){
                                temp = head ;
                                while ( temp -> next != NULL )
                                        temp = temp -> next ;
                                temp -> next= x.head ;  

                     }
               }       

        }

/*
 * Destructor.
 * Frees all the memory acquired by the list.
 */
        template<typename T>
        list<T>::~list(){
 
                int k=count;
                while(!this->empty()){
                         this->remove(k);
                         k--;
                }
        }

 /*
         * Seondary constructor.
         * Creates a new list which is a copy of the provided list.
         */
        template<typename T>
        list<T>::list(const list<T> & x) : count(0),head(NULL), tail(NULL){
 
                  Node* current = x.head;

                  while(current != NULL){
                        this->append(current->data);
                        current=current->next;
                  }
         }

// display the all value containing the table 
        template <typename T>
        void list<T>::dump() {
    
        // std::cout << "(";

        Node* current = head;

     if (current != NULL) {
   
        while (current->next != NULL) {
            std::cout <<current->key<<","<<current->data <<std::endl;
            current = current->next;
        }
        //std::cout << current->data;
        std::cout <<current->key<<","<<current->data <<std::endl;
                        }

    //std::cout << ")"<<std:: endl;
                             }

   


           
}    


#endif


