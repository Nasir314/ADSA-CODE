/*
 * ChainedMap.hpp
 *
 */

#ifndef CHAINEDMAP_HPP_
#define CHAINEDMAP_HPP_


#include "list_mod.hpp"
#include "Dictionary.hpp"
#include<iostream>
#include<stdlib.h>
#define SIZE 119
using namespace ansari;
using namespace std;


namespace eni
{
template<class Key, class Value>
class ChainedMap : public Dictionary<Key,Value>    // inheritance (Base class and derived class ))
{
	//void rehash();
private:
       //vector<string> *M[SIZE];
       list<string> L[SIZE];
       int factor;
public:
     
	 bool has(const Key& key);    
	 void remove(const Key& key);    
	 Value get(const Key& key);
	 void put(const Key& key, const Value& value) ;
	 int code(const Key& key);  /////////////////////////////////////////
         void Display();

	ChainedMap();
	ChainedMap(const int& num);    
	ChainedMap(ChainedMap<Key, Value>& ht);    
	~ChainedMap();
	Value& operator[](const Key& key);
        
};

 /*
     * A convenience wrapper operator.
     * Returns a reference to the value corresponding to the given key.
     * If the key does'nt exist, then inserts the key in the table,
     * with the default value of the Value type.
     * This should enable you to write code like this:
     * ChainedHashMap<int,int> ht;
     * ht[1] = 2;
     * ht[1] = 4;
     * ht[2] = 3;
     */


template<class Key, class Value>
ChainedMap<Key,Value>::ChainedMap(ChainedMap<Key, Value>& ht){
           for(int i=0;i<SIZE;i++)
               L[i].append(ht[i]);
            //for(int i=0;i<num;i++)
              //   l[i]=0;
           
           factor=SIZE;
}

template<class Key, class Value>
ChainedMap<Key,Value>::~ChainedMap(){
          for(int i=0;i<SIZE;i++){
               if(L[i].empty()!=1){
                       int j=L[i].length();
                       for(int i=1;i<=j;i++)
                            L[i].remove(i);
              }
         }
  factor=SIZE;
}


 template<class Key, class Value>

  Value& ChainedMap<Key,Value>:: operator[](const Key& key)
	{
              return get(key);
	   }

 /*
     * Constructor: ChainedMap
     * Creates a Chained Hash Table with some default size.
     * NOTE: Please try to ensure that the size is a prime number for better performance.
     */

template<class Key, class Value>
ChainedMap<Key,Value>::ChainedMap(){
          // for(int i=0;i<SIZE;i++)
            //     M[i]=&L[i];
           factor=SIZE;
}

/*
     * Constructor:ChainedMap
     * Creates an empty Chained Map with the ability to hold atleast num Key value pairs.
     */

template<class Key, class Value>
ChainedMap<Key,Value>::ChainedMap(const int& num){
          //for(int i=0;i<num;i++)
            //     M[i]=&L[i];
           factor=num;
}

 /*
     * Function : put
     * If the key does'nt exist in the dictionary, then insert the given key and value in the dictionary.
     * Otherwise change the value associated with the key to the given value.
     */

template<class Key, class Value>
void ChainedMap<Key,Value>::put(const Key& key, const Value& value){
         int index=code(key);
         L[index].cons(key,value);
}

/*
     * Function : has
     * Returns true if the dictionay contains the key
     * false otherwise. It is search operation
     */

template<class Key, class Value>
bool ChainedMap<Key,Value>::has(const Key& key){
         int index=code(key);
          list<string> temp;
          temp.append(L[index]);
          int flag=0;
          int j=0;
          int c=L[index].length();
         while((flag!=1)&&(j!=c)){
                   if(key==temp.next1()){
                        flag=1;
                        return 1;
                    }
               j++;
             //cout<<L[index].next1();
          
         }
         return 0;
}

/*
     * Function : get
     * Returns the value associated with the given key.
     * Raises an exception if the key does'nt exist in the dictionary.
     */
template<class Key, class Value>
Value ChainedMap<Key,Value>::get(const Key& key){
          int index=code(key);
          list<string> temp;
          list<string> temp1;
          //string key1;
          temp.append(L[index]);
          temp1.append(L[index]);
          int flag=0;
          int j=0;
          int c=L[index].length();
           cout<<c<<endl;
         while((flag!=1)&&(j!=c)){
                   if(key==temp.next1()){
                        flag=1;
                        //key1=temp1.next2();
                        return temp1.next2();
                    }
               j++;
            
         }
         return 0;
}

 /*
     * Function : remove
     * Removes the given key and the corresponding value from the Dictionary if the key is in the dictionary.
     * Does nothing otherwise.
     */
template<class Key, class Value>
void ChainedMap<Key,Value>::remove(const Key& key){
        int index=code(key);
          list<string> temp;
          temp.append(L[index]);
          int flag=0;
          int j=0;
          int l=0;
          int c=L[index].length();
         while((flag!=1)&&(j!=c)){
                   if(key==temp.next1()){
                        flag=1;
                        c++;
                        //return temp.next();
                    }
                  l++;
         }
         //return 0;
         if(flag==1)
             L[index].remove(l);
         
}


template<class Key, class Value>
int ChainedMap<Key,Value>::code(const Key& key){
               long long int k=0;
               int i=0;
               while(key[i]!='\0'){
                        i++;
              }
              int c=i;
              c=c-1;
              for(int j=0;j<i;j++)
                  k=k+pow(39,j)*(int)key[c-j];
              return k%factor;
   }

/*
     * Function : Display
     * it Display the all keys and value containing the hash table */
template<class Key, class Value>
   void ChainedMap<Key,Value>::Display(){
          for(int i=0;i<SIZE;i++){
               if(L[i].length()!=0)
                  L[i].dump();               
          }
   }
  
}

#endif /* CHAINEDMAP_HPP_ */
