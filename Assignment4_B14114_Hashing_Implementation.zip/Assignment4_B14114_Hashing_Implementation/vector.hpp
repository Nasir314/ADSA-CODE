/*
 * vector.hpp
 *
 * A template file for implementing a resizable vector. 
 */

#ifndef VECTOR_HPP
#define VECTOR_HPP

#include <iostream>
#include <new>

namespace ansari{
template<class Item>       //Templates are the foundation of generic programming, which involves writing code in a way that is independent of any particular type.The library containers like iterators and algorithms are examples of generic programming and have been developed using template concept.
 
class vector{                // define a class 
private:
    Item* v;        //pointer to vector
    int n;          //size of vector
    int capacity;   //max capacity

public:
	vector();      //default constructor
        vector(const int& isize);       //constructor with argument
        vector(const int& isize, const Item& ival);     //constructor with argument
	vector(vector &obj);		//copy constructor
	void vector_copy(vector &obj);
	~vector();     //destructor
	inline Item& operator[](const int& i);     //return stored value at index i
	void push_back(const Item& item);      //insert value at the end of vector
	bool empty();      //check for empty vector
	int size();        //return size of vector
	int get_capacity();
	void setn(const int nval);   
	void fill(const Item& item);      //replace all value of vector by item
    void print();       //print current vector
    void pop_back();

    class iterator{		//for iteration
    private:
        Item * p;
    public:

        void operator++(){
            ++p;
        }

        void operator--(){
            --p;
        }

        bool operator==(Item *t){
            return p == t;
        
}
        bool operator!=(Item *t){
            return p != t;
        }

        void operator=(Item *t){
            p = t;
        }

        void operator=(const iterator &it){
            p = it.p;
        }

        Item& operator*(){
            return *p;
        }

    };

    Item* begin();
    Item* end();
};
 /*Default constructor. Should create an empty vector that
     * not contain any elements*/
template<class Item>
vector<Item>::vector(){
    v=NULL;
    n=0;
    capacity=0;
}

/*This constructor should create a vector containing isize elements. You can intialize the elements with any values.*/
template<class Item>
vector<Item>::vector(const int& isize){
    n=isize;
    v=new Item[isize];
    capacity=isize;
    for(int i=0;i<isize;++i)
        v[i]=0;
}

/* This contructor also creates a vector containing isize elements.
     * All the elements must be initialized with the value ival.
     * */	
template<class Item>
vector<Item>::vector(const int& isize, const Item& ival){
    n=isize;
    capacity=isize;
    v=new Item[isize];
    for(int i=0;i<isize;++i)
        v[i]=ival;
}

template<class Item>
vector<Item>::vector(vector<Item> &obj)
{
	//delete[] v;
	v = new Item[obj.size()];
	for(int i=0;i<obj.size();++i)
		v[i]=obj[i];
	//*v = *obj.v;		//copies the values
	n = obj.size();
	capacity = obj.get_capacity();
}

template<class Item>
void vector<Item>::vector_copy(vector<Item> &obj)
{
	if(v!=NULL)
		delete[] v;
	v = new Item[obj.size()];
	for(int i=0;i<obj.size();++i)
		v[i]=obj[i];
	//*v = *obj.v;		//copies the values
	n = obj.size();
	capacity = obj.get_capacity();
}

/*Destructor.
     * Must free all the memory contained by the vector*/
	
template<class Item>
vector<Item>::~vector(){
    delete[] v;
}

template<class Item>
inline Item& vector<Item>::operator[](const int& i){
    return v[i];
}

// push function using for push the valuse in the last of vector

template<class Item>
void vector<Item>::push_back(const Item& item){
    if(capacity==0)
    {
        v=new Item;
        capacity=1;
        n=1;
        v[0]=item;
    }    
    else
    {
        if(capacity==n)
        {
            Item* temp=new Item[capacity*2];
            capacity=capacity*2;
            int i=0;
            while(i<n)
            {
                temp[i]=v[i];
                ++i;
            }
            delete[] v;
            v=temp;
        }

            v[n]=item;
            ++n;
    }

}


template <class Item> 
void vector<Item>::pop_back()
{
  	--n;
}
//check for empty vector
template<class Item>
bool vector<Item>::empty(){
    if(n==0)
        return 1;
    else
        return 0;
}
//return size of vector
template<class Item>
int vector<Item>::size(){
    return n;
}

template<class Item>
int vector<Item>::get_capacity(){
    return capacity;
}

template <class Item>
void vector<Item>::setn(const int nval)
{
	n=nval;
}
//replace all value of vector by item
template<class Item>
void vector<Item>::fill(const Item& item){
    for(int i=0;i<n;++i)
        v[i]=item;
}
//print current vector
template<class Item>
void vector<Item>::print(){
    for(int i=0;i<n;++i)
        std::cout<<v[i]<<"\n";
}

template<class Item>
Item* vector<Item>::begin(){
    return v;
}

template<class Item>
Item* vector<Item>::end(){
    return v+n;
}



}
#endif
