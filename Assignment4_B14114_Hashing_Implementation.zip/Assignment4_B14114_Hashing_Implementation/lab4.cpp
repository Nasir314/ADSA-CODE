#include<iostream>
#include "OpenMap.hpp"
#include "DoubleHashMap.hpp"
#include "ChainedMap.hpp"
#include "Dictionary.hpp"
#include<cstring>
#include<string.h>


using namespace std;
using namespace eni;
//using namespace ansari1;
//namespace ansari;

int main(){
     
       int inp=0,inp1=0;
       string key,value;
       Dictionary<string,string> *ht1;
       ChainedMap<string,string> ht2;
       OpenMap<string,string> ht3;
       DoubleHashMap<string,string> ht4;
       cout<< endl;
cout<<"********************************************** Choose your operation here  ***************************************************"<<endl;
	cout<<"-----------------------------------------------------------------------------------------------------------------------------"<<endl;
       cout<<endl;
      // cout<<"Choose which Collision Method You want to Apply : \n";
       cout<<"1.Chaining operation----------------------> \n2.Linear Probing operation-----------------> \n3.Double Hashing operation------------------> \n";
       cin>>inp;
       switch(inp){
          
            case 1:
                   ht1=&ht2;
                   break;
            case 2:
                   ht1=&ht3;
                   break;
            case 3:
                   ht1=&ht4;
                   break;
            default:
cout << endl << endl ;
cout<<"*************************************************  Enter your correct input here ************************************************* \n";
                   break;
 
     		 }
      
      if (inp == 1 || inp == 2 || inp == 3 ) {
     while (1){
             
             cout<<endl;          
             cout<<"******************************************************************************************************************************"<<endl;
	cout<<"-----------------------------------------------------------------------------------------------------------------------------"<<endl;
             cout<<endl;
             cout << "1.Insert operation-------------------------> \n2.Delete operation--------------------->\n3.Search for Key is present or Not---------> \n4.Search operation---------------------> \n5.Display operation---------------------> \n6.Exit---------------------------->\n";
             cin >> inp1;
              // if (inp1 == 1 || inp1 == 2 || inp1 == 3 || inp1 == 4 || inp1 == 5 || inp1 == 6 ) {   
             switch(inp1){
	               
                  case 1:
	                 cout << "Enter Key and Value----------------------------------------------------------->" << endl;
	                 cin >> key >> value;
	                 ht1->put (key, value);
	                 break;
	         case 2:
	                 cout << "Enter key associated with value to delete it---------------------------------->\n";
	                 cin >> key;
	                 ht1->remove (key);
	                 break;
	         case 3:
	                 cout <<"Enter key associated with value to be searched for its presence----------------->"<< endl;
	                 cin >> key;
	                 if (ht1->has (key) == 1){	  
	                         cout << "------------------ Value is present for given value ------------------" << endl;
	                 }
	                 else{	    
	                         cout << "------------------------------ Not Present ----------------------------" << endl;
	                 }
                         break;
	         case 4:
	                 cout << "Enter key associated with value to be searched --------------------------------->" << endl;
	                 cin >> key;
	                 if (ht1->has (key) == 1){
	                         cout << key << " : " << ht1->get (key) << endl;
	                 }
	                 else{
	                         cout << "------------------------------  Not present -------------------------------------";
	                 }
	                 break;
	         case 5:
                       cout<<endl;          
cout<<"------------------------------------------- Your number in the Hash table is as follow ---------------------------------------"<<endl;
	               ht1->Display ();
cout<<"------------------------------------------------------------------------------------------------------------------------------"<<endl;
	               break;
	
		 case 6:
			exit(1);
                default:
cout<<"---------------------------------------------------------   Thanks for using    ----------------------------------------------"<<endl;
                       cout<<endl;          
                       cout<<"-----------------------------------------------------------------------------------------------------------------------------"<<endl;
                       cout<<endl;
			} }
	
	

    			}	
	else {
	cout << endl<< endl << endl ;
	/*cout << " *************************************************  enter write input ************************************************"<<endl;*/ }
}
 
                   

