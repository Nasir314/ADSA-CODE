#include<iostream>
#include "Disjoint_set.hpp"
#include "AdjacencyList.hpp"
#include <fstream>
#include <sstream>

using namespace std;

struct edge{
	int src;
	int dest;
	int weight;
  
};

int main(){
	AdjacencyList alist;
	Disjoint Dis;
	string filename;
	int i,j,num,gp[100][100];
	struct edge edge1[100];
 	ifstream Myfile (filename.c_str ());
 	cout<<"Enter filename : ";
 	cin>>filename;
 	Myfile.open (filename.c_str ());
 	if (Myfile.good()){
    			string str;
    			while(getline(Myfile, str)){
        			istringstream ss(str);
        			int num;
        			while(ss >> num){
            			gp[i][j]=num;
            			j++;
        			}
       				i++;
       				j=0;
    			}
    }
    int t=i;
    int c=0;
    int p;
	for(i=0;i<t;i++){
		p=0;
    	for(j=0;j<t;j++){ 
         	if(gp[i][j]!=0){
         		if(p!=1){
         			Dis.make_set(i);
              
         			p=1;
         		}
            
         		edge1[c].src=i;
         		edge1[c].dest=j;
         		edge1[c].weight=gp[i][j];
         		c++;

          
                alist.add(i,j);
        	}
    	}
    }

    //for(i=0;i<t;i++){}

    int min,temp_weight,temp_src,temp_dest;
    for(i=0;i<c;i++){
       min=i;
       for(j=i+1;j<c;j++){
           if(edge1[j].weight < edge1[min].weight)
                min=j;
       }
       temp_weight=edge1[min].weight;
       temp_src=edge1[min].src;
       temp_dest=edge1[min].dest;
       edge1[min].weight=edge1[i].weight;
       edge1[min].src=edge1[i].src;
       edge1[min].dest=edge1[i].dest;
       edge1[i].weight=temp_weight;
       edge1[i].src=temp_src;
       edge1[i].dest=temp_dest;
	}

	cout<<"======================================= Linked List Representation of graph =========================================="<<endl;
	cout<<"______________________________________________________________________________________________________________________\n"<<endl;
	alist.display();
	cout<<endl;

	int m=0,a[100],l=0;
	for(i=0;i<c;i++){
    
		if(Dis.find_set(edge1[i].src)!=Dis.find_set(edge1[i].dest)){
			Dis.make_union(edge1[i].src,edge1[i].dest);
			a[m]=i;
			m++;
		}
	}

	cout<<"=========================================== Kruskal Algorithm for minimum spanning tree ==================================\n";
	//cout<<"_____________________________________________\n"<<endl;
	for(i=0;i<m;i++){
		l++;
		cout<<"Step ->  "<<l<<endl;
		//cout<<"_______\n"<<endl;
		for(j=0;j<l;j++)
			cout<<"src : "<<edge1[a[j]].src<<"  -----> "<<" dest : "<<edge1[a[j]].dest<<"  ::  "<<"Weight -> "<<edge1[a[j]].weight<<endl;

		cout<<endl;
			
	}


}
