#ifndef HEAP
#define HEAP 1
#define INT_MIN -1

class Binaryheap{
	private:
		int H_size;
		int k;
		int v;
		int Arr[100];
		int index1[1000000];
	public:
		Binaryheap();
		//~Heap();
		int extract_min(int Arr[]);
		void Binaryheap_insert(int Arr[],int k);
		void Binaryheap_Decrease_key(int Arr[],int v,int k);
		void Heapify(int Arr[],int v);
		int size();
		int parent(int v);
		int left(int v);
		int right(int v);
		
		int index(int k);
};



int Binaryheap::extract_min(int Arr[]){
	int min=Arr[0];
	Arr[0]=Arr[H_size];
	H_size=H_size-1;
	Heapify(Arr,0);
	return min;

}

void Binaryheap::Binaryheap_insert(int Arr[],int k){
	H_size=H_size+1;
	Arr[H_size]= INT_MIN;
	Binaryheap_Decrease_key(Arr,H_size,k);
}



void Binaryheap::Binaryheap_Decrease_key(int Arr[],int v,int k){
	Arr[v]=k;
	index1[k]=v;
	while((v>0)&(Arr[parent(v)]>Arr[v])){
		int p;
		p=Arr[v];
		Arr[v]=Arr[parent(v)];
		Arr[parent(v)]=p;
		v=parent(v);
	}
}

void Binaryheap::Heapify(int Arr[],int v){
	int l=left(v);
	int r=right(v);
	int smallest;
	if((l<=H_size)&(Arr[l]<Arr[v]))
		smallest=l;
	else 
		smallest=v;

	if((r<=H_size)&(Arr[r]<Arr[smallest]))
		smallest=r;

	if(smallest!=v){
		int m=Arr[v];
		Arr[v]=Arr[smallest];
		Arr[smallest]=m;
		Heapify(Arr,smallest);
	}
}


Binaryheap::Binaryheap(){
	H_size=0;
}

int Binaryheap::parent(int v){
	return v/2;
}

int Binaryheap::index(int k){
	return index1[k];
}

int Binaryheap::left(int v){
	return 2*v;
}

int Binaryheap::size(){
	return H_size;
}

int Binaryheap::right(int v){
	return 2*v+1;
}

#endif
