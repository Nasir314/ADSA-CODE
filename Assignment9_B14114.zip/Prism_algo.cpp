#include<iostream>
#include "BinaryHeap.hpp"
#include <fstream>
#include <sstream>
#include "AdjacencyList.hpp"
#define INT_MAX 10000
using namespace std;
struct ed
{
    int src;
    int dest;
    int weight;
  
};



int main()
   {
Binaryheap H;
AdjacencyList alist;
int l=1;
string f_name;
int i=0,j=0,k=0;

struct ed ed1[100];

int ver[100], par[100],key[100], S[100], result[100];

int gra[100][100];
ifstream Myfile (f_name.c_str ());

cout<<"Enter f_name ------------>>>>>>>> ";
cin>>f_name;
Myfile.open (f_name.c_str ());


 	if (Myfile.good())
	{
		string str;
		while(getline(Myfile, str))
		{
			istringstream ss(str);
			int num;
			while(ss >> num)
			{
    			gra[i][j]=num;
    			j++;
			}

			i++;
			j=0;
		}

       }

int P=i;
int c=0;
for(i=0;i<P;i++)
{
   for(j=0;j<P;j++)
	{ 
          if(gra[i][j]!=0)
	    {

 		ed1[c].src=i;
 		ed1[c].dest=j;
 		ed1[c].weight=gra[i][j];
 		c++;          
                alist.add(i,j);
            }
    	}
}

for(i=0;i<c;i++)
    {
    	H.Binaryheap_insert(ver,INT_MAX);
    	key[i]=INT_MAX;
    	S[i]=0;
    }

key[0]=0;
H.Binaryheap_Decrease_key(ver,0,0);
int p;
    

while(H.size()!=0)

	{
    	    int u=H.extract_min(ver);
    	    p=H.index(u);
           
           if((p>=0)&&(p<=P))
            {
    	        if(S[p]==0)
                  {
    		    result[p]=u;
    		    k++;
                    S[p]=1;
    	          }    

    	   for(j=0;j<P;j++)
              { 
         	  if(gra[p][j]!=0)
                     {
         		 if(S[j]==0)
                            {
         			    if((key[j]>gra[p][j])&&(gra[p][j]!=0))
                                       {
         				   key[j]=gra[p][j];
                                            par[j]=p;                      
         			       }                       
                                    H.Binaryheap_Decrease_key(ver,j,key[j]);      
         		     }      		
        	     }
    	     }
        
          }

      }

    cout<<"\n\n====================================== AdjacencyList Representation of gra ==================================\n\n"<<endl;
    alist.display();

    cout<<"\n\n";
    cout<<"\n\n ============================================   Prim's Algorithm for MST ===========================================\n\n";
    //cout<<"\n\n";
    for(i=1;i<k;i++)
     {
        l++;
        cout<<"STEP ------------- >>> "<<l-1<<endl;
        cout<<"\n";
        for(j=1;j<l;j++)
            cout<<"Src :"<<par[j] <<"-----"<< "des :"<<j<<" ---------->   "<<"Weight :"<<result[j]<<endl;

        cout<<"\n\n";
     }
return 0;
}
