#include<cstdlib>
#include<cstring>
namespace ansari
{
template <class item>     //Templates are the foundation of generic programming, which involves writing code in a way that is independent of any particular type.The library containers like iterators and algorithms are examples of generic programming and have been developed using template concept.


class vector   // define a class 
{

private:   // private excess specifire 
	
	item *array1;
	
	unsigned int size;   
	int cap;
	const static int dy=128;
	
public:
	
	vector();      /*Default constructor. Should create an empty vector that
     * not contain any elements*/

	vector(const int& isize);     /*This constructor should create a vector containing isize elements. You can intialize the elements with any values.*/

	vector(const int& isize,const item& ival);     /* This contructor also creates a vector containing isize elements.
     * All the elements must be initialized with the value ival.
     * */

	~vector();                  /*Destructor.
     * Must free all the memory contained by the vector*/
	void push_back(const item& ival);  // push function using for push the valuse in the last of vector
	bool empty();        /*Returns true if the vector is empty, false otherwise.
     * */
	unsigned int findsize();
	 
	int &operator[](int ival)
	{
	return array1[ival];	
	}
	

		};

template <class item>
vector <item> :: vector()   // here we are using constructor out side the class  using resolution operator 
{
	array1 = NULL;  // set array1 at null
	size = 0;
	cap = dy;
}

template <class item>
vector <item> :: vector(const int& isize)
{
	size = 0;
	cap = isize;
	array1 = new item [isize];  // allocate the memory dynamically in cpp with new operator just like as in c language malloc,calloc etc.
}

template <class item>
vector <item> :: vector(const int& isize,const item& ival)
{
	size=0;
	cap=isize;
	array1=new item [isize];   // allocate the memory dynamically in cpp with new operator just like as in c language malloc,calloc etc
	int i;
	for(i=0;i<isize;i++)
	array1[i]=ival;
	size=isize;
}


template <class item>
vector <item> :: ~vector()
{
	delete[] array1;  // using the delete for free of memory 
}

template <class item>
void vector <item> :: push_back(const item& ival)  // pushing the value in the last in vector using of push_back function .
{
	if(size==0)
	{
		array1=new item[1];
		array1[0]=ival;
		size=1;		
	}
	else
		{
			
			item *temp=new item[size+1];
			int j=0;
			while(j<size)
		{
			temp[j]=array1[j];
			j++;
		}
			temp[j]=ival;
			delete[] array1;
			array1=temp;
			size++;
	        }

}

template <class item>
unsigned int vector <item> :: findsize()  
{
return size;
}

template <class item>
bool vector<item> :: empty()   /*Returns true if the vector is empty, false otherwise.
     * */
{
	if(size==0)
	return true;
	else
	false;
}
}























	



   
