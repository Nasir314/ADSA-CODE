#include"ansari.h" 
#include<iostream> 
#include<cstring> 
using namespace ansari;

void output(vector<int> &array) // using for printig the the vector element 
{ 
	for(unsigned int i=0; i<array.findsize(); i++) 
		std::cout << array[i] << " : ";   //Without using namespace std; when you write for example cout <<; you'd have to put std::cout <<;//
               std::cout <<"\n"; 
} 
 
int main() 
{ 
	vector<int> arr1;
        vector<int> arr2(25);
        vector<int> arr3(10,10);

	arr1.push_back(1);    /* This push_back functions add the given element at the end of the vector
     * It should increase the vector size by 1.*/
	arr1.push_back(17);
	arr1.push_back(40);
	arr1.push_back(57);
	arr1.push_back(70);

        arr2.push_back(80);
        arr2.push_back(15);
        arr2.push_back(25);
        arr2.push_back(11);
	
        arr3.push_back(70);
        arr3.push_back(94);
        arr3.push_back(11);
        arr3.push_back(10);

	std::cout << "\n\n";  
	std::cout << "*******************************************************************************************************";
        std::cout << "\n\n";
	std::cout << "arr1 :";
        output(arr1);
	std::cout << "\n";
	 
	std::cout << "arr2 :";
	output(arr2);
	std::cout << "\n";

	std::cout << "arr3 :";
	output(arr3);
	std::cout << "\n";

	if(arr1.empty()) {
	std::cout << "arr1 is full\n" ;
	output(arr1);    }
	else
	std::cout << "empty\n";
	int size;
	size=arr1.findsize();
	std::cout << "The size of the arr is :  "<< size <<"\n";
	std::cout << "\n";
        std::cout<<"\nIf we want to claculate the size and Vector is full or empty then we can 'like arr1' \n";
	std::cout << "*****************************************************************************************************";
	
	return 0;
} 
 

