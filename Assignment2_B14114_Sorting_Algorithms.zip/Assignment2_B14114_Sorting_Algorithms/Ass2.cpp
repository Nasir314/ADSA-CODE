#include<iostream>
#include<fstream>
#include<string>
#include "vector.hpp"
#include "sorter.hpp"
#include "timer.hpp"
//#include "graph.hpp"

using namespace ansari;
using namespace std;

int main ()
{
  vector < int >array;
  sorter < int >sort;

  clock_t start_time;
  clock_t end_time;
  timer clk;

  //graph plt;
  int input, input1, lo, hi, i, c = 0, a, choice, choice1, remain = 1,z;

  string filename;
  ifstream Myfile (filename.c_str ());
  ofstream file_;


  cout << "**********************************************************************************************************************************";
  cout <<
    "\n\nChoose your Input method >> \n 1. By User >> \n 2.From File >> \n" <<
    endl;
  cout << "Enter your input here >> ";
  cin >> choice1;
  switch (choice1)
    {
    case 1:
      while (remain == 1)
	{
	  cout << "\nHow many elements you want to insert >>"<< endl;
	  cin >> input;
          cout<<"Insert your elements Here >>" ;
	  while (input-- > 0)
	    {
	      cin >> input1;
	      array.push_back (input1);
	    }
	  cout << "\nwant to insert more elements in this Array if\nYES  press 1 \nNO Press 0 \n" << endl;
	  cin >> remain;
	}
      cout<<"\nTotal Number of Inputs in this Array is >>\n "<<array.size()<<endl;
      cout <<"\nEnter Inputs  >> "<<endl;
      for (i = 0; i < array.size (); i++)
	cout << array[i]<<"  ";
      cout<<endl;
     
      lo=0;
      hi=array.size()-1;
      break;
    case 2:
      cout << "\nEnter your file  name >>";
      cin >> filename;
      Myfile.open (filename.c_str ());
      Myfile >> a;
      while (!Myfile.eof ())
	{

	  array.push_back (a);
	  Myfile >> a;
	  c++;
	}
      Myfile.close ();
      cout<<"\n\nTotal Number of Inputs is >>"<<c<<endl;
      cout <<"\nEntered Inputs >>\n "<<endl;
      for (i = 0; i < array.size (); i++)
	cout << array[i]<<"  ";
      cout<<endl;
      
      lo=0;
      hi=array.size()-1;
      break;

   default :
         cout<<"\n\n############################################    Enter Between the given choices    ######################################\n\n"<<endl;
         break;
    }



cout<<"*********************************************************************************************************************************"<<endl;
cout<<"\n*********************************************************************************************************************************"<<endl;
    
cout << "\nYou want see answer of all sorting algorithms if Yes Press 1 >> ";
cout << "\nYou want see answer of Partucular sorting algorithms Press 0 >> ";
cout << "\n\nEnter your Answer here >> ";
cin >> z;

if(z == 0) {
  cout<<"*********************************************************************************************************************************"<<endl;
cout<<"\n*********************************************************************************************************************************"<<endl;
    
  cout <<
    "1.Insertion Sort\n2.Selection Sort\n3.Rank Sort\n4.Bubble Sort\n5.Quick Sort\n6.Merge Sort\n7.Bubble Sort(Improved Version)\n"
    << endl;
  cout<<"\nChoose your Algorithms >>> \n"<<endl;

  cin >> choice;

  switch (choice)
    {

    case 1:
      cout << "\nsorting using insertion sort is as follows:\n"; 
      clk.start();
      sort.insertion_sort (array, lo, hi);
      clk.stop();
      for (i = 0; i < array.size (); i++)
	cout << array[i]<< "  ";
      cout << endl;
      clk.print();
      file_.open("insertion.txt", std::ios_base::app);
      file_<<hi-lo+1<<"  "<<clk.last_timing();
      //file_.close();
      //plt.plot("insertion.txt");
      break;

    case 2:
      cout << "\nsorting using selection sort is as follows:\n";
      clk.start();
      sort.selection_sort (array, lo, hi);
      clk.stop();
      for (i = 0; i < array.size (); i++)
	cout << array[i]<< "  ";
      cout << endl;
      clk.print();
      file_.open("selection.txt", std::ios_base::app);
      file_<<array.size()<<"  "<<clk.last_timing()<<endl;
      break;

    case 3:
      cout << "\nsorting using Rank Sort is as follows:\n";
      clk.start();
      sort.rank_sort (array, lo, hi);
      clk.stop();
      for (i = 0; i < array.size (); i++)
	cout << array[i]<< "  ";
      cout << endl;
      clk.print();
      file_.open("rank.txt", std::ios_base::app);
      file_<<array.size()<<"  "<<clk.last_timing();
      break;
    case 4:
      cout << "\nsorting using Bubble Sort is as follows:\n";
      clk.start();
      sort.bubble_sort (array, lo, hi);
      clk.stop();
      for (i = 0; i < array.size (); i++)
	cout << array[i]<< "  ";
      cout << endl;
      clk.print();
      file_.open("bubble.txt", std::ios_base::app);
      file_<<array.size()<<"  "<<clk.last_timing();
      break;
    case 5:
      cout << "\nsorting using Quick sort is as follows:\n";
      clk.start();
      sort.quick_sort (array, lo, hi);
      clk.stop();
      for (i = 0; i < array.size (); i++)
	cout << array[i]<< "  ";
      cout << endl;
      clk.print();
      file_.open("quick.txt", std::ios_base::app);
      file_<<array.size()<<"  "<<clk.last_timing();
      break;
    case 6:
      cout << "\nsorting using Merge Sort is as follows:\n";
      clk.start();
      sort.merge_sort (array, lo, hi);
      clk.stop();
      for (i = 0; i < array.size (); i++)
	cout << array[i]<< "  ";
      cout << endl;
      clk.print();
      file_.open("merge.txt", std::ios_base::app);
      file_<<array.size()<<"  "<<clk.last_timing();
      break;
    case 7:
      cout << "\nsorting using Improved Bubble Sort is as follows:\n";
      clk.start();
      sort.improved_bubble_sort (array, lo, hi);
      clk.stop();
      for (i = 0; i < array.size (); i++)
	cout << array[i]<< "  ";
      cout << endl;
      clk.print();
      file_.open("improved_bubble.txt", std::ios_base::app);
      file_<<array.size()<<"  "<<clk.last_timing();
      break;
     /*case 8:
      cout << "sorting using Improved Rank Sort is as follows:\n";
      clk.start();
      sort.improved_rank_sort (array, lo, hi);
      clk.stop();
      for (i = 0; i < array.size (); i++)
	cout << array[i]<< "  ";
      cout << endl;
      clk.print();
      file_.open("improved_rank.txt", std::ios_base::app);
      file_<<array.size()<<"  "<<clk.last_timing();
      break;*/
      
     default :
         cout<<"\n\n########################################   Enter Between the given choices  #############################################\n\n"<<endl;
         break;


    }
cout<<"**********************************************************************************************************************************"<<endl;
cout<<"\n*********************************************************************************************************************************\n\n"<<endl;
    
}  


   



else
 {


cout<<"\n\n*********************************************************************************************************************************"<<endl;
  cout<<"\n*********************************************************************************************************************************"<<endl;
  
      cout << "\n";

      cout << "\nsorting using insertion sort is as follows:\n"; 
      clk.start();
      sort.insertion_sort (array, lo, hi);
      clk.stop();
      for (i = 0; i < array.size (); i++)
	cout << array[i]<< "  ";
      cout << endl;
      clk.print();
      file_.open("insertion.txt", std::ios_base::app);
      file_<<hi-lo+1<<"  "<<clk.last_timing();
      //file_.close();
      //plt.plot("insertion.txt");
      
      cout << "\n";
    
      cout << "\nsorting using selection sort is as follows:\n";
      clk.start();
      sort.selection_sort (array, lo, hi);
      clk.stop();
      for (i = 0; i < array.size (); i++)
	cout << array[i]<< "  ";
      cout << endl;
      clk.print();
      file_.open("selection.txt", std::ios_base::app);
      file_<<array.size()<<"  "<<clk.last_timing()<<endl;
      
      cout << "\n";
    
      cout << "\nsorting using Rank Sort is as follows:\n";
      clk.start();
      sort.rank_sort (array, lo, hi);
      clk.stop();
      for (i = 0; i < array.size (); i++)
	cout << array[i]<< "  ";
      cout << endl;
      clk.print();
      file_.open("rank.txt", std::ios_base::app);
      file_<<array.size()<<"  "<<clk.last_timing();
      
      cout << "\n";  
  
      cout << "\nsorting using Bubble Sort is as follows:\n";
      clk.start();
      sort.bubble_sort (array, lo, hi);
      clk.stop();
      for (i = 0; i < array.size (); i++)
	cout << array[i]<< "  ";
      cout << endl;
      clk.print();
      file_.open("bubble.txt", std::ios_base::app);
      file_<<array.size()<<"  "<<clk.last_timing();
      
      cout << "\n";
    
      cout << "\nsorting using Quick sort is as follows:\n";
      clk.start();
      sort.quick_sort (array, lo, hi);
      clk.stop();
      for (i = 0; i < array.size (); i++)
	cout << array[i]<< "  ";
      cout << endl;
      clk.print();
      file_.open("quick.txt", std::ios_base::app);
      file_<<array.size()<<"  "<<clk.last_timing();
      
      cout << "\n";
    
      cout << "\nsorting using Merge Sort is as follows:\n";
      clk.start();
      sort.merge_sort (array, lo, hi);
      clk.stop();
      for (i = 0; i < array.size (); i++)
	cout << array[i]<< "  ";
      cout << endl;
      clk.print();
      file_.open("merge.txt", std::ios_base::app);
      file_<<array.size()<<"  "<<clk.last_timing();
      
      cout << "\n";
    
      cout << "\nsorting using Improved Bubble Sort is as follows:\n";
      clk.start();
      sort.improved_bubble_sort (array, lo, hi);
      clk.stop();
      for (i = 0; i < array.size (); i++)
	cout << array[i]<< "  ";
      cout << endl;
      clk.print();
      file_.open("improved_bubble.txt", std::ios_base::app);
      file_<<array.size()<<"  "<<clk.last_timing();
     
      cout <<"\n\n";

      
     /* cout << "sorting using Improved Rank Sort is as follows:\n";
      clk.start();
      sort.improved_rank_sort (array, lo, hi);
      clk.stop();
      for (i = 0; i < array.size (); i++)
	cout << array[i]<< "  ";
      cout << endl;
      clk.print();
      file_.open("improved_rank.txt", std::ios_base::app);
      file_<<array.size()<<"  "<<clk.last_timing();*/
      
      

cout<<"\n\n**********************************************************************************************************************************"<<endl;
cout<<"\n**********************************************************************************************************************************\n\n"<<endl;
   
}

return 0;

}  


  





















