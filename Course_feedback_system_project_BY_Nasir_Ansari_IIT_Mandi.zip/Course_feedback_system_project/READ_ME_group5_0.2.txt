                                                        COURSE FEEDBACK SYSTEM
                                                        ======================

Introduction :
-------------

Course feedback is an important tool in the development of teaching.Constructive feedback gives teachers valuable information about students' experiences during the course and about the possible needs for improvements.This tool will provide a user friendly system to get feedbacks about various courses from students.Teachers can see the feedbacks about their courses and can modify their teaching skills as per the requirements.



Documentation :
--------------

Documentation of this project such as SRS(System Requirement Settings) and Design document is attached within the main folder.



Installation :
-------------

1).Copy this file in a directory which is path of your web server root. For example in Ubuntu you can paste it in the directory whose path is / var/www/html

2).From web browser: go to the following link: http://localhost/Feedback_System/mysql/setup.php

3).Then give database name and provide root password to access your mysql account.This will automatically create reqiured databases in mysql server.Also you need to give username and password for course feedback system.

4).You now need to setup the primary configuration file that Feedback System requires to successfully administer the application. In the directory "Feedback_System/classes/" you will find a file crc_constants.mod.php. Open this file and modify MYSQL_SERVER, MYSQL_PORT, MYSQL_DB, MYSQL_USER and MYSQL_PASS constants to reflect the connection parameters that need to be used when Feedback System interacts with the MySQL database.

5).Now in browser go to the link http://localhost/Feedback_System/ . It will provide a login menu; you can first log in as administrator for which default username : admin and password : admin is set. Now enjoy !

Setting Up Profiles:
--------------------

1).First step is to register a student to give Feedback, for registering login to admin mode.

2).After logging in you will find a button Register,register the user as teacher or student by using the drop down menu option.

3).After registering Admin is logged out and student can login and enroll in a certain course if added newly.

4). A course can be alloted to teacher by admin only in Edit course Option or while adding the course.

To Give Feedback:
-----------------

1). Log in By using user name and password of student to give feedback.

2). After logging in click on courses button, a table is appeared,in Action column of the table click on Evaluate button if not given feedback,if already given You can not give a feedback again.

To see a Feedback:
------------------
1).Login using faculty login user name and password.

2).To see feedback click on Feedback button.

3). A table is appeared click on course id to see the feedback of that course.


Notice :
--------

It is a project under our course Database and Manangement Systems .It cannot be used commercially.



By :
----

Group No.-5_0


1).Kapardi Trivedi(B14110)
2).Nasir Ansari(B14114)
3).Yogendra Kumar Dhiwar(B14141)

