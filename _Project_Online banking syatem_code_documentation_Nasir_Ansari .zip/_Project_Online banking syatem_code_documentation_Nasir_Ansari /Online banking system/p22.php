<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '123456789';
$connect = mysql_connect($dbhost,$dbuser,$dbpass );
mysql_select_db("n_v");

if (!$connect){
           echo "Could not connect";
}
else{
echo "Connection successfully made";
if(isset(@$_POST["Create"] <> ""){
  $CustomerId = $_POST['CustomerId'];
  $AccountNumber = $_POST['AccountNumber'];
  $Password = $_POST['Password'];
  $AccountBalance = $_POST['AccountBalance'];
  $AccountType =$_POST['AccountType'];
   

               echo "Account successfully created";
               echo "<h1>$CustomerId</h1>";
              echo "<h1>$AccountNumber</h1>";
              echo "<h1>$Password</h1>";
              echo "<h1>$AccountType</h1>";
$query= "select * from Accounts where AccountNumber=('$AccountNumber')";
$result = mysql_query($query);			  

      $query = mysql_query("INSERT INTO Accounts VALUES('$CustomerId','$AccountNumber','$Password','$AccountBalace','$AccountType')") ;
    }


else if(isset(@$_POST["Login"] <> ""){
$AccountNumber = $_POST['AccountNumber'];
$query= "select * from Accounts where AccountNumber=('$AccountNumber')";
$result = mysql_query($query);
$row = mysql_fetch_array($result);
echo "Account successfully opened";
}
             }
mysql_close($connect);
?>
</html>


