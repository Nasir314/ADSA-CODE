<html>
<head>
<title>table</title>
</head>
<body>
<table border="1px" align="center" width="1350" cellspacing="1x">
<tr align="center" bgcolor="LawnGreen " height="250px"><td colspan=2><big><font size="10">Online Banking System</font></big></td></tr> 
<tr height="300px" bgcolor="PaleTurquoise "><td colspan=2>
 <form method="post" action="lab6_part6.php">
<div align="center"><b><font size="6">*****Enter Details*****</font></b><br><br><br>
Account number                  <input type="text" name="acc_no"  required="required"  /><br>
    customer id                 <input type="text" name="cust_id" required="required"  /><br>
Account Balance                 <input type="text" name="bal" required="required"/><br>
   Account type(Saving,Current) <input type="text" name="acc_type" required="required"/><br><br><br>
<input type="submit" name="submit" value="submit"/>
<input type="reset" name="reset" value="reset"/>
</form></div>
<?php
$username="root";$password="123456789";$database="nasir_ansari";
$conn = mysql_connect(localhost,$username,$password);
mysql_select_db($database) or die( "Unable to select database");
  
if (@$_POST["submit"] <> "") {
$acc_no = $_POST['acc_no'];
  $cust_id = $_POST['cust_id'];
  $bal = $_POST['bal'];
  $acc_type =$_POST['acc_type']; 
}
$query = mysql_query("INSERT INTO account VALUES('$acc_no','$cust_id','$bal','$acc_type')") ;	
mysql_close($conn);
?>
<b><a href="lab6.php">Back To Home page</a></b>
</td></tr>
<tr bgcolor="LawnGreen " height="50px"><td colspan=6></td></tr>
</table>
</body>
</html>
