<?php

			  $connect = mysql_connect("localhost","nasir","123456789" );
      mysql_select_db("nasir_ansari");

if(isset($_POST['Create'])){
  $CustomerId = $_POST['CustomerId'];
  $AccountNumber = $_POST['AccountNumber'];
  $Password = $_POST['Password'];
  $AccountType =$_POST['AccountType']; 

               
               echo "<h1>$CustomerId</h1>";
              echo "<h1>$AccountNumber</h1>";
              echo "<h1>$Password</h1>";
              echo "<h1>$AccountType</h1>";
			  

      $query = mysql_query("INSERT INTO showtable VALUES('$name','$rollnumber','$add','$dept')") ;
    }


else if(isset($_POST['login'])){
$AccountNumber = $_POST['AccountNumber'];
$result = mysql_query('SELECT *FROM Accounts WHERE AccountNumber = $AccountNumber');
$row = mysql_fetch_array($result);
}

?>
