<html>
<body>
<?php
$username="paddy";$password="xxxxx";$database="demo";
mysql_connect(localhost,$username,$password);
@mysql_select_db($database) or die( "Unable to select database");

$dno=$_POST['dno'];
echo "You entered dnumber $dno";

echo "<br>";
echo "The result is:";
echo "<br>";

$query="SELECT * FROM department where dnumber = $dno";
$result=mysql_query($query);
$num = mysql_num_rows($result);

echo "<table>";
while ($row = mysql_fetch_array($result)) {
	echo "<tr>";
	echo "<td>" . $row['dname'] . "</td>";
	echo "<td>" . $row['dnumber'] . "</td>";
	echo "<td>" . $row['mgr_ssn'] . "</td>";
	echo "<td>" . $row['mgr_start_date'] . "</td>";
	echo "</tr>";
}
echo "</table>";

echo "<br>";
echo "$num rows returned";

mysql_close();



?>
</body>
</html>
