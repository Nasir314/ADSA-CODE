<?php
$username="root";$password="123456789";$database="nasir_ansari";
mysql_connect(localhost,$username,$password);
@mysql_select_db($database) or die( "Unable to select database");
$query="SELECT * FROM Users  ";
$result=mysql_query($query);
$num = mysql_num_rows($result);
while ($row = mysql_fetch_array($result)) {
        echo "<tr>";
        echo "<td>" . $row['Userid'] . "</td>";
        echo "<br />\n";
        echo "<td>" . $row['Email'] . "</td>";
        echo "<br />\n";
        echo "<td>" . $row['Mobile'] . "</td>";
        echo "<br />\n";
        echo "</tr>";
}
mysql_close();
?>

