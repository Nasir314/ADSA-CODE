<head>
<title>table</title>
</head>
<body>
<table border="1px" align="center" width="1350" cellspacing="1x">
<tr align="center" bgcolor="LawnGreen " height="250px"><td colspan=2><big><font size="10">Online Banking System</font></big></td></tr> 
<tr height="300px" bgcolor="PaleTurquoise "><td colspan=2> <form action="lab6_part5.php" method="post">
<div align="center"><b><font size="5">View your Account Details</font></b><br><br>
<div align="center"><b>Enter Account Number:</b><br>
<input type="text" name="acc_no" required="required" /><br><br>
<input type="submit" name="submit" value="submit"/>
<input type="reset" name="reset" value="reset"/>
</form></div>
<b><a href="lab6.php">Back To Home page</a></b>
</td></tr>
<tr bgcolor="LawnGreen " height="50px"><td colspan=6></td></tr>
</table>
</body>
</html>
