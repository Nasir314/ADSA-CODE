<!DOCTYPE html>
<html>
<body>
 <h1 style="text-align:center">Online Banking System </h1>
<form action="p22.php">
  <h3>Login your account</h3>
  AccountNumber:<br>
  <input type="text" value="AccountNumber">
  <br>
  Password:<br>
  <input type="password" name="lastname" value="password">
  <br><br>
   <input type="submit" value="Login">
  <br>
   <h3>Create New Account</h3>
   <br>
   CustomerId:<br>
  <input type="text" value="CustomerId" >
  <br>
  AccountNumber:<br>
  <input type="text" value="xxxxxxxxxxxxxxxx">
  <br>
Password:<br>
  <input type="password" name="lastname" value="password">
  <br><br>
  AccountBalance:<br>
  <input type="integer" value="AccountBalance" value="balance">
  <br>
  <p>AccountType</p>  
  <select name="AccountType">
    <option value="Saving">Saving</option>
    <option value="Current">Current</option>
    </select>
  <br><br>
  <input type="submit" value="Create">
  
</form> 


</body>

</html>

