#ifndef STACK_HPP_
#define STACK_HPP_
#include<cstdlib>
#include<cstring>

namespace ansari
{
  template<class Item>
    class stack
    {
      private:
      	node<Item>*head;
      public:
        node<Item>*create_node(Item d);

        stack();

        node<Item> * getHead();

        void push(const Item& t);

        Item pop();

        Item top();

        int size();

        inline bool empty();

        ~stack();

        void append(list<Item>& x);
    };
        template <class Item>
    node<Item>* stack <Item>::create_node(Item d)   // creating a new node 
		{
			node<Item>*temp = new node<Item>[1];
			temp->data = d;
			temp->next = NULL;
			return temp;
		}
        /*
         * Constructs a new stack.
         */
    template<class Item>
	stack<Item> ::stack()
	{
	head = NULL;
	}
	    /*
         * Pushes t on to the top of the stack.
         */
    template<class Item>
	void stack<Item> :: push(const Item& value)
	{
    	Item data = value;
    	node<Item>*temp = create_node(value);
    	temp->next = head;
    	head = temp; 
	}
        /*
         * Returns the element at the front of the stack.
         * Also removes the front element from the stack.
         */
    template <class Item>
    Item stack<Item>::pop()
	{
         node<Item>*temp = head;
		 head = temp->next;
		 Item t = temp->data;
		 delete(temp);
		 return t;	
	}
        /*
         * Returns the element at the front of the stack.
         * Dsnt remove the front element from the stack.
         */
    template <class Item>
    Item stack<Item>::top()
	{
		 Item t = head->data;
		 return t;	
	}
        /*
         * Returns the number of elements currently in the stack.
         */
	template<class Item>
	inline int stack<Item> :: size()
	{
		node<Item>*temp = head;
		int l = 0;
		while(temp != NULL){
			l++;temp = temp->next;
		}
		return l;
	}
        /*
         * Returns a boolean indicating whether the stack is empty or not.
         */
	template<class Item>
	inline bool stack<Item> :: empty()
	{
	    if(head == NULL)return true;
		else return false;	
	} 
        /*
         * Destructor
         * Fress the memory occupied by the stack elements.
         */
    template <class Item>
    stack<Item> :: ~stack(){
    	node<Item>*temp = head;
    	while(temp != NULL){
    		node<Item>*temp1 = temp;
    		temp = temp->next;
			delete(temp1);
		}
	}
	template <class Item>
	node<Item> *stack<Item>::getHead()
	{
		return head;
	}
}

#endif
