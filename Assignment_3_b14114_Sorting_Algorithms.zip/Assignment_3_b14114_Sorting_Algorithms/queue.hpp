#ifndef QUEUE_HPP_
#define QUEUE_HPP_
#include<cstdlib>
#include<cstring>

namespace ansari
{
  /*template <class Item>
  struct node{
	Item data;
	node<Item> *next;
};*/
template <class Item>
    class queue
    {
      private:
      	node<Item> *head;
      public:
        node<Item> *create_node(Item d);
        queue();

        void push(const Item& t);

        node<Item> * getHead();

        Item pop();

        Item front();

        inline int size();

        inline bool empty();

        ~queue();
    };
    template <class Item>
    node<Item> * queue <Item>::create_node(Item d){
			node<Item> *temp = new node<Item>[1];
			temp->data = d;
			temp->next = NULL;
			return temp;
		}
        /*
         * Constructs a new queue.
         */
    template<class Item>
	queue<Item> ::queue()
	{
	head = NULL;
	}
	    /*
         * Pushes t to at the back of the queue.
         */
    template<class Item>
	void queue<Item> :: push(const Item& value)
	{
		Item d = value;
		node<Item> *temp1 = head;
		if(head == NULL)head = create_node(d);
		else{
		while(temp1->next!= NULL){
			temp1 = temp1->next;
		}
		temp1->next = create_node(d);
			} 
	}
        /*
         * Returns the element at the front of the queue.
         * Also removes the front element from the queue.
         */
    template <class Item>
    Item queue<Item>:: pop()
	{
         node<Item> *temp = head;
		 head = temp->next;
		 Item t = temp->data;
		 delete(temp);
		 return t;	
	}
        /*
         * Returns the element at the front of the queue.
         * Dsnt remove the front element from the queue.
         */
    template <class Item>
    Item queue<Item>::front()
	{
		 Item t = head->data;
		 return t;	
	}
        /*
         * Returns the number of elements currently in the queue.
         */
	template<class Item>
	inline int queue<Item> :: size()
	{
		node<Item> *temp = head;
		int l = 0;
		while(temp != NULL){
			l++;temp = temp->next;
		}
		return l;
	}
        /*
         * Returns a boolean indicating whether the queue is empty or not.
         */
	template<class Item>
	inline bool queue<Item> :: empty()
	{
	    if(head == NULL)return true;
		else return false;	
	} 
        /*
         * Destructor
         * Fress the memory occupied by the queue elements.
         */
    template <class Item>
    queue<Item> :: ~queue(){
    	node<Item> *temp = head;
    	while(temp != NULL){
    		node<Item> *temp1 = temp;
    		temp = temp->next;
			delete(temp1);
		}
	}

	template <class Item>
	node<Item> *queue<Item>::getHead()
	{
		return head;
	}
}
#endif
