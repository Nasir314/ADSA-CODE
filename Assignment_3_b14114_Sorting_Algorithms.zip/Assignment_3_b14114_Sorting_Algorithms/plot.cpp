#include <iostream>
#include <string>
#include <cstdio>

using namespace std;
int main()
{
	
    // For Graph
    //FILE* graph = fopen("AscSortedReading", "w");
    //fprintf(graph, "Size\tInsertionSort\tMergeSort\tSelectionSort\tQuickSort\tBubbleSort\tOptBubbleSort\tRankSort\tOptRankSort\n");

    string commandsForGnuplot[] = {"set term x11 0" ,
     "set title \"All sorting algoritms compare time complexity------->.\"",
     "set key outside","set xlabel 'Input Size ----->            1st counting, 2nd bucket list, 3rd bucket stack, 4th bucket queue '", "set ylabel 'Time(sec) ------>              '",
      "plot for [col=2:7] 'all.txt' using 1:col with line title columnheader"};



    FILE * gnuplotPipe = popen ("gnuplot -p", "w");
    for (int i=0;i<6;i++)
        fprintf(gnuplotPipe, "%s \n", commandsForGnuplot[i].c_str());
    //fclose(graph);
    pclose(gnuplotPipe);   
    return 0;
}
