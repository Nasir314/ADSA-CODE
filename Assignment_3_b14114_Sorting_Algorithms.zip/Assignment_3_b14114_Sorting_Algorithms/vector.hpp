/*
 * vector.hpp
 *
 * A template file for implementing a resizable vector. 
 */

#ifndef VECTOR_HPP_
#define VECTOR_HPP_
#include<cstdlib>
#include<cstring>
namespace ansari
{
template < class Item >      //Templates are the foundation of generic programming, which involves writing code in a way that is independent of any particular type.The library containers like iterators and algorithms are examples of generic programming and have been developed using template concept.
 


class vector       // define a class 
  {
  public:
     vector ();		 /*Default constructor. Should create an empty vector that
     * not contain any elements*/
	
    ~vector ();		/*Destructor.
     * Must free all the memory contained by the vector*/
	
     void push_back (const Item & item);	      // push function using for push the valuse in the last of vector

     bool empty();        /*Returns true if the vector is empty, false otherwise.
     * */
   		
     unsigned int size ();   // calculate the size 
	
     vector (const int &isize);	    /*This constructor should create a vector containing isize elements. You can intialize the elements with any values.*/

    inline Item & operator[] (const int &i);

    void fill (const Item & item);
    
    vector (const int &isize, const Item & ival);    /* This contructor also creates a vector containing isize elements.
     * All the elements must be initialized with the value ival.
     * */	

  private:     // private excess specifire
      Item * array;

    unsigned int asize;		
    int cap;			
    const static int dyns = 128;
    const static int dynm = 2;

  };


 template < class Item > 
 inline Item & vector < Item >::operator[](const int &i)	
  {

    return array[i];
  }


  template < class Item >
  vector < Item >::vector ()   // here we are using constructor out side the class  using resolution operator 
  {
    array = NULL;  // set array at null
    asize = 0;

  }

  template < class Item >
  vector < Item >::vector (const int &isize)
  {
    asize = 0;
    cap = isize;
    array = new Item[isize];  // allocate the memory dynamically in cpp with new operator just like as in c language malloc,calloc etc.
  }



  template < class Item >
  vector < Item >::vector (const int &isize, const Item & ival)
  {
    asize = 0;
    cap = isize;
    array = new Item[isize];   // allocate the memory dynamically in cpp with new operator just like as in c language malloc,calloc etc.
    int i;
    for (i = 0; i < isize; i++)
      array[i] = ival;
    asize = isize;
  }
  template < class Item >
  vector < Item >::~vector ()
  {

    delete[]array;  // using the delete for free of memory 


  }

  template < class Item > 
  void vector < Item >::push_back (const Item & item)   // pushing the value in the last in vector using of push_back function .
  {
    if (asize == 0)
      {
	array = new Item[1];
	array[0] = item;
	asize = 1;
      }
    else
      {
	Item *temp;
	temp = new Item[asize + 1];
	int j = 0;
	while (j < asize)
	  {
	    temp[j] = array[j];
	    j++;
	  }
	temp[j] = item;
	delete[]array;
	array = temp;
	asize++;
      }
  }


  template < class Item > 
  unsigned int vector < Item >::size ()
  {
    return asize;
  }

  template < class Item >
  bool vector < Item >::empty ()   /*Returns true if the vector is empty, false otherwise.
     * */
  {
    if (asize == 0)
      return true;
    else
      false;
  }

  template < class Item >
  void vector < Item >::fill (const Item & item)
  {
    int i = 0;
    int k;
    for (i = 0; i < asize; i++)
      {
	array[i] = item;
      }
  }

}
#endif
