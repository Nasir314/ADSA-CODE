#ifndef LIST_HPP
#define LIST_HPP 1
#include<cstdlib>
#include<cstring>
namespace ansari
{
	
template<class Item>
struct node{
	Item data;
	node<Item> *next;
};	

template<class Item>
    class list
    {
	  private:
	  node<Item> *head;	
      public:
        list();

        list(const list<Item> & x);

        ~list();
        
        node<Item> *create_node(Item d);
        
        node<Item> * getHead();
        
        void append(const Item& value);

        inline int length();

        inline bool empty();

        void cons(const Item& value);

        void remove(const Item & x);

        void append(list<Item>& x);
    };
    template <class Item>
    node<Item>  * list <Item>::create_node(Item d) // creating a new node 
		{
			node<Item> *temp = new node<Item>[1];
			temp->data = d;
			temp->next = NULL;
			return temp;
		}
    
        /*
         * Primary contructor.
         * Should construct an empty list.
         * Size of the created list should be zero.
         */
	template<class Item>
	list <Item> ::list()
	{
	head = NULL;
	}
        /*
         * Seondary constructor.
         * Creates a new list which is a copy of the provided list.
         */
	template<class Item>
	list<Item> ::list(const list<Item> & x)
	{
	head = NULL;
	node<Item> *temp = x;
	head = create_node(temp->data);
	node<Item> *temp1 = head;
	temp = temp->next;
	while(temp != NULL){ 
		temp1->next = create_node(temp->data);
		temp1 = temp1->next;
		temp = temp->next;
	}
	}
/*
 * Destructor.
 * Frees all the memory acquired by the list.
 */
	template<class Item>
	list<Item> ::~list()
	{
	   /* node<Item> *temp = head;
		node<Item> *temp1 ;
    	while(temp != NULL){
    		
    		temp1 = temp->next;
			delete(temp);
			temp = temp1;
	                       }*/
         }
/*
 * adds value at the end of the list.
 */
	template<class Item>
	void list<Item> :: append(const Item& value)
	{
		Item d = value;
		if(head == NULL)head = create_node(d);
		else{
                node<Item> *temp1 = head;
		while(temp1->next != NULL){
			temp1 = temp1->next;
		}
		temp1->next = create_node(d);
			} 
	}
/*
 * Returns the length of the list.
 */	
	template<class Item>
	inline int list<Item> :: length()
	{
		node<Item> *temp = head;
		int l = 0;
		while(temp != NULL){
			l++;temp = temp->next;
		}
		return l;
	}
/*
 * Returns a boolean indicating whether the list is empty.
 */
	template<class Item>
	inline bool list<Item> :: empty()
	{
	    if(head == NULL)return true;
		else return false;	
	} 
/*
 * Adds a value to the front of the list.
 */
 	template<class Item>
	void list<Item> :: cons(const Item& value)
    {
    	Item data = value;
    	node<Item> *temp = create_node(value);
    	temp->next = head;
    	head = temp;
	}
/*
 * Removes the first occurence of the value from list.
 */
  	template<class Item>
	void list<Item> :: remove(const Item& value)
    {
    	Item d = value;int c = 0;
    	node<Item> *temp = head;
    	if(head == NULL)return;
    	if(head->data == d){
        		node<Item> *temp1 = head;
        		head = head->next;
        		delete(temp1);
        		return;
			}
        while(temp->next != NULL)
		{
        	if(temp->next->data = d)
			{
        		node<Item> *temp1 = temp->next;
        		temp->next = temp1->next;
        		delete(temp1);
			}
		}
		return;
     }
	
	template <class Item>
	node<Item> *list<Item>::getHead()
	{
		return head;
	}
 /*
 * Appends the given list x at the end of the current list.
 */
   	template<class Item>
	void list<Item> :: append(list<Item>& x)
	{
		node<Item> *temp = head;
                if(head == NULL)head = x.getHead();
                else{
		while(temp->next != NULL){
			temp = temp->next;
		}

		temp->next = x.getHead();
	} }
}


#endif
