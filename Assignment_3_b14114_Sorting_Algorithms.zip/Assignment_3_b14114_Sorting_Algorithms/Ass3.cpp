#include<iostream>
#include<fstream>
#include<string>
#include "vector.hpp"
#include "sorter.hpp"

#include "stack.hpp"
#include "queue.hpp"
#include "timer.hpp"
#include "list.hpp"
//#include "graph.hpp"

using namespace ansari;
using namespace std;

int main ()
{
  vector < int >array;
  sorter < int >sort;

  clock_t start_time;
  clock_t end_time;
  timer clk;

  //graph plt;
  int input, input1, lo, hi, i, c = 0, a, choice, choice1, remain = 1,z;

  string filename;
  ifstream Myfile (filename.c_str ());  // stream class to read from file
  ofstream file_,file_2,file_3,file_4;// stream class to writes on files



  cout<<"**********************************************************************************************************************************";
  cout <<"\n\nChoose your Input method >> \n 1. By User >> \n 2.From File >> \n" <<endl;
  cout << "Enter your input here >> ";
  cin >> choice1;
  switch (choice1)
    {
    case 1:
       while (remain == 1)
	 {
	cout << "\nHow many elements you want to insert >>"<< endl;
	cin >> input;
	cout<<"Insert your elements Here >>" ;
	     while (input-- > 0)
	       {
	         cin >> input1;
	         array.push_back (input1);
	       }
	  cout << "\nwant to insert more elements in this Array if\nYES  press 1 \nNO Press 0 \n" << endl;
	  cin >> remain;
	 }
	cout<<"\nTotal Number of Inputs in this Array is >>\n "<<array.size()<<endl;
	cout <<"\nEnter Inputs  >> "<<endl;
	for (i = 0; i < array.size (); i++)
	cout << array[i]<<"  ";

	cout<<endl;
	lo=0;
	hi=array.size();
   break;

    case 2:
      cout << "\nEnter your file  name >>";
      cin >> filename;
      Myfile.open (filename.c_str ());
      Myfile >> a;
      while (!Myfile.eof ())
	{

	  array.push_back (a);
	  Myfile >> a;
	  c++;
	}
      Myfile.close ();
      cout<<"\n\nTotal Number of Inputs is >>"<<c<<endl;
      cout <<"\nEntered Inputs >>\n "<<endl;
      for (i = 0; i < array.size (); i++)
	cout << array[i]<<"  ";
      cout<<endl;
      
      lo=0;
      hi=array.size();
      break;

   default :
         
cout<<"\n\n############################################    Enter Between the given choices    ######################################\n\n"<<endl;
     break;
    }



cout<<"*********************************************************************************************************************************"<<endl;
cout<<"\n*********************************************************************************************************************************"<<endl;
    
cout << "\nYou want see answer of all sorting algorithms if Yes Press 1 >> ";
cout << "\nYou want see answer of Partucular sorting algorithms Press 0 >> ";
cout << "\n\nEnter your Answer here >> ";
cin >> z;

if(z == 0) {
  cout<<"*********************************************************************************************************************************"<<endl;
cout<<"\n*********************************************************************************************************************************"<<endl;
    
  cout <<
    "1.Counting sort\n2.Bucket sort from list\n3.Bucket sort from stack\n4.bucket sort from queue\n"<< endl;
  cout<<"\nChoose your Algorithms >>> \n"<<endl;

  cin >> choice;

  switch (choice)
 {

    case 1:
      cout << "\nsorting using counting sort is as follows:\n"; 
      clk.start();
      sort.counting_sort(array, lo, hi);
      clk.stop();
      for (i = 0; i < array.size (); i++)
	cout << array[i]<< "  ";
      cout << endl;
      clk.print();
      file_.open("counting.txt", std::ios_base::app);
      file_<<array.size()<<"  "<<clk.last_timing();
      break;
      //file_.close();
      //plt.plot("insertion.txt");
    
   case 2:
      cout << "\nsorting using bucket list sort is as follows:\n";
      clk.start();
      sort.bucket_list(array, lo, hi);
      clk.stop();
      for (i = 0; i < array.size (); i++)
      cout << array[i]<< "  ";
      cout << endl;
      clk.print();
      file_2.open("bucket_list.txt", std::ios_base::app);
      file_2<<array.size()<<"  "<<clk.last_timing()<<endl;
      break;

    case 3:
      cout << "\nsorting using bucket stack Sort is as follows:\n";
      clk.start();
      sort.bucket_stack(array, lo, hi);
      clk.stop();
      for (i = 0; i < array.size (); i++)
	cout << array[i]<< "  ";
      cout << endl;
      clk.print();
      file_3.open("bucket_stack.txt", std::ios_base::app);
      file_3<<array.size()<<"  "<<clk.last_timing();
      break;
    case 4:
      cout << "\nsorting using bucket queue Sort is as follows:\n";
      clk.start();
      sort.bucket_queue(array, lo, hi);
      clk.stop();
      for (i = 0; i < array.size (); i++)
	cout << array[i]<< "  ";
      cout << endl;
      clk.print();
      file_4.open("bucket_queue.txt", std::ios_base::app);
      file_4<<array.size()<<"  "<<clk.last_timing();
      break;

     default :
         cout<<"\n\n########################################   Enter Between the given choices  #############################################\n\n"<<endl;
         break;


    }
cout<<"**********************************************************************************************************************************"<<endl;
cout<<"\n*********************************************************************************************************************************\n\n"<<endl;
    
  }  

else 
	{


      cout << "\nsorting using counting sort is as follows:\n"; 
      clk.start();
      sort.counting_sort(array, lo, hi);
      clk.stop();
      for (i = 0; i < array.size (); i++)
      cout << array[i]<< "  ";
      cout << endl;
      clk.print();
	 cout << endl;
      file_.open("counting.txt", std::ios_base::app);
      file_<<array.size()<<"  "<<clk.last_timing();
      //file_.close();
      //plt.plot("insertion.txt");
     

   
      cout << "\nsorting using bucket list sort is as follows:\n";
      clk.start();
      sort.bucket_list(array, lo, hi);
      clk.stop();
      for (i = 0; i < array.size (); i++)
      cout << array[i]<< "  ";
      cout << endl;
      clk.print();
	 cout << endl;
      file_2.open("bucket_list.txt", std::ios_base::app);
      file_2<<array.size()<<"  "<<clk.last_timing()<<endl;
    

   
      cout << "\nsorting using bucket stack Sort is as follows:\n";
      clk.start();
      sort.bucket_stack(array, lo, hi);
      clk.stop();
      for (i = 0; i < array.size (); i++)
      cout << array[i]<< "  ";
      cout << endl;
      clk.print();
	 cout << endl;
      file_3.open("bucket_stack.txt", std::ios_base::app);
      file_3<<array.size()<<"  "<<clk.last_timing();
    
      cout << "\nsorting using bucket queue Sort is as follows:\n";
      clk.start();
      sort.bucket_queue(array, lo, hi);
      clk.stop();
      for (i = 0; i < array.size (); i++)
      cout << array[i]<< "  ";
      cout << endl;
      clk.print();
	 cout << endl;
      file_4.open("bucket_queue.txt", std::ios_base::app);
      file_4<<array.size()<<"  "<<clk.last_timing();
      

	}



cout<<"**********************************************************************************************************************************"<<endl;
cout<<"\n*********************************************************************************************************************************\n\n"<<endl;


}







